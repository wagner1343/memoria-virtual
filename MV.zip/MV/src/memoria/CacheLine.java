package memoria;

public class CacheLine {
}
