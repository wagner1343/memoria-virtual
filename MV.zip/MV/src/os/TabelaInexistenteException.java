package os;

public class TabelaInexistenteException extends Exception {
}
