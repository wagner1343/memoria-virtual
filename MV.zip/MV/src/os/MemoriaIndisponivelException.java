package os;

public class MemoriaIndisponivelException extends  Exception {
}
