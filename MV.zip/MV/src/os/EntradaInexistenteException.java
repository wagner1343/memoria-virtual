package os;

public class EntradaInexistenteException extends  Exception {
}
