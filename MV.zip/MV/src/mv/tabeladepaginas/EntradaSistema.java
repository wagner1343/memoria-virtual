package mv.tabeladepaginas;

public class EntradaSistema {
    private int addr;
    private boolean disponivel;

    public EntradaSistema(int addr, boolean disponivel){
        this.addr = addr;
        this.disponivel = disponivel;
    }

    public int getAddr() {
        return addr;
    }

    public void setAddr(int addr) {
        this.addr = addr;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    public String toString()
    {
        return "addr: " + addr + " disp: " + disponivel;
    }
}
