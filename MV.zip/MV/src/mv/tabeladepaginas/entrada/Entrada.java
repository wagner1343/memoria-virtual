package mv.tabeladepaginas.entrada;

public class Entrada {
    private int addr;
    private boolean disco;

    public Entrada(int addr){
        this.addr = addr;
        disco = false;
    }


    public boolean isDisco() {
        return disco;
    }

    public void setDisco(boolean disco) {
        this.disco = disco;
    }

    public int getAddr() {
        return addr;
    }

    public void setAddr(int addr) {
        this.addr = addr;
    }

    public String toString(){
        return "addr: " + addr + "disco: " + disco;
    }
}
